import CPUData
open HDLean HDLean.Backend
set_option maxRecDepth 1000000
set_option maxHeartbeats 16000000
theorem cpuWF : CPUStages.candidate.wellFormed = true := by decide +kernel
