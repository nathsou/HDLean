import HDLean.Backend.LocalValidate
open HDLean HDLean.Backend
namespace HDLean.Backend.Local

def indexByList (ctx : Context g i r) : Index g i r :=
  let rec go (gs : List Gate) (h : ∀ a, a ∈ gs → a ∈ g.gates.toList)
      (table : Index g i r) : Index g i r :=
    match gs with
    | [] => table
    | gate::rest =>
      let e : AndEntry g i r := ⟨gate.a, gate.b, ⟨2*gate.lhs, meaning_gate ctx _ (h _ (by simp))⟩⟩
      go rest (fun a ha => h a (List.mem_cons_of_mem _ ha)) (table.insert (gate.a,gate.b) e)
  go g.gates.toList (fun _ h => h) {}

def checkByList (g : Graph) (c : Circuit d i r o) (hint : Expr d i r → Nat := pointerHint) :
    Option (PLift (g.Equivalent c)) := do
  if hw : g.wellFormed = true then do
    if hi : g.inputs = i+1 then do
      if hr : g.latches = r then do
        if hn : g.next.size = r then do
          if ho : g.outputs.size = o then do
            if ht : Ordered (g.inputs+g.latches+1) g.gates.toList then do
              let table := indexByList ⟨hi,hr,ht⟩
              let job : StateT (Memo g d i r) Option
                  (PLift (∀ j : Fin r, j ∈ List.finRange r → meaning g g.next[j.val] = nextMeaning c j) ×
                   PLift (∀ j : Fin o, j ∈ List.finRange o → meaning g g.outputs[j.val] = outputMeaning c j)) := do
                let ns ← allChecked (P := fun j : Fin r => meaning g g.next[j.val] = nextMeaning c j) (fun j : Fin r => do liftM (checkRoot (← checkNext c table hint j) g.next[j.val])) (List.finRange r)
                let os ← allChecked (P := fun j : Fin o => meaning g g.outputs[j.val] = outputMeaning c j) (fun j : Fin o => do liftM (checkRoot (← checkOutput c table hint j) g.outputs[j.val])) (List.finRange o)
                return (ns,os)
              let (ns,os) ← job.run' {}
              return ⟨by
                refine ⟨hw,hi,hr,ho,?_⟩
                intro xs s rst
                apply Prod.ext
                · apply Array.ext
                  · simp [Graph.eval, hn]
                  · intro j h₁ h₂
                    have hj : j < r := by simpa using h₂
                    have h := ns.down ⟨j,hj⟩ (List.mem_finRange _)
                    have h := congrFun (congrFun (congrFun h xs) s) rst
                    simpa [Graph.eval, meaning, nextMeaning] using h
                · apply Array.ext
                  · simp [Graph.eval, ho]
                  · intro j h₁ h₂
                    have hj : j < o := by simpa using h₂
                    have h := os.down ⟨j,hj⟩ (List.mem_finRange _)
                    have h := congrFun (congrFun (congrFun h xs) s) rst
                    simpa [Graph.eval, meaning, outputMeaning] using h⟩
            else none
          else none
        else none
      else none
    else none
  else none

end HDLean.Backend.Local
namespace HDLean.Backend

def Graph.validateByList (g : Graph) (c : Circuit d i r o)
    (hint : Expr d i r → Nat := Local.pointerHint) : Bool :=
  (Local.checkByList g c hint).isSome

theorem Graph.validateByList_sound (g : Graph) (c : Circuit d i r o)
    (hint : Expr d i r → Nat := Local.pointerHint)
    (h : g.validateByList c hint = true) : g.Equivalent c := by
  unfold Graph.validateByList at h
  cases hc : Local.checkByList g c hint with
  | none => simp [hc] at h
  | some proof => exact proof.down
end HDLean.Backend
