import CPUData
import HDLean.Backend.LocalValidate
open HDLean HDLean.Backend
set_option maxRecDepth 1000000
set_option maxHeartbeats 16000000
namespace CPUStages
theorem context : Local.Context candidate 0 4288 := by
  refine ⟨by decide, by decide, ?_⟩
  decide +kernel
end CPUStages
