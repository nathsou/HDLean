#!/usr/bin/env python3
"""Replay a bounded CPU kernel resource experiment; this is not an acceptance gate."""
import argparse
import json
import os
from pathlib import Path
import resource
import shutil
import sys
import time

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--project', type=Path, required=True)
p.add_argument('--lean', type=Path, required=True)
p.add_argument('--memory-mb', type=int, default=12288)
p.add_argument('--output', type=Path)
a = p.parse_args()
project, lean = a.project.resolve(), a.lean.resolve()
output = (a.output or project / 'work/cpu-resource-reproduction').resolve()
output.mkdir(parents=True, exist_ok=True)
sys.path.insert(0, str(project / 'scripts'))
from comparator.sandbox import limited_run
from comparator.compare import DEFAULT_LIMITS
modules = ['CPUData', 'CPUWF', 'CPUContext', 'IndexByList', 'CheckGiven', 'ShallowHint', 'CPUGraphGivenRaw']
limits = dict(DEFAULT_LIMITS, memory_mb=a.memory_mb, cpu_seconds=600, wall_seconds=660)
report = {'certificate_passed': False, 'limits': limits, 'stages': []}
report_path = output / 'measurement.json'
report_path.unlink(missing_ok=True)
for name in modules:
    source = output / (name + '.lean')
    shutil.copyfile(Path(__file__).resolve().parent / source.name, source)
    (output / (name + '.olean')).unlink(missing_ok=True)
start = time.monotonic()
try:
    for name in modules:
        stage = {'module': name}
        report['stages'].append(stage)
        tick = time.monotonic()
        try:
            limited_run(['/usr/bin/env', 'LEAN_NUM_THREADS=2',
                'LEAN_PATH=' + os.pathsep.join(map(str, [project / '.lake/build/lib/lean', output,
                                                       lean.parent.parent / 'lib/lean'])),
                lean, '-j2', '-M' + str(a.memory_mb - 512), '-R', output,
                '-o', output / (name + '.olean'), output / (name + '.lean')],
                output / (name + '.log'), limits, cwd=project)
            stage['status'] = 'passed'
        finally:
            stage['seconds'] = round(time.monotonic() - tick, 3)
            stage['cumulative_child_peak_rss_kib'] = resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss
    report['certificate_passed'] = True
except (OSError, RuntimeError, TimeoutError) as error:
    report['failure'] = str(error)
    print(error, file=sys.stderr)
finally:
    report['seconds'] = round(time.monotonic() - start, 3)
    report_path.write_text(json.dumps(report, indent=2) + '\n')
    print(report_path)
raise SystemExit(0 if report['certificate_passed'] else 1)
