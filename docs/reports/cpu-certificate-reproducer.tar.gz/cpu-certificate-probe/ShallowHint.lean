import HDLean.Backend.LocalValidate
import Designs.Toy16.Hardware
import Designs.Toy16.Programs
open HDLean HDLean.Backend
set_option maxRecDepth 1000000
set_option maxHeartbeats 16000000
namespace CPUProbe

def shallow : Nat → Expr d i r → Nat
  | _, .lit b => if b then 1 else 0
  | _, .input j => (11*j.val+2)%1000000007
  | _, .reg j => (13*j.val+3)%1000000007
  | 0, .inv _ => 4
  | 0, .and _ _ => 5
  | 0, .xor _ _ => 6
  | 0, .mux _ _ _ => 7
  | n+1, .inv a => (17*shallow n a+4)%1000000007
  | n+1, .and a b => (19*shallow n a+23*shallow n b+5)%1000000007
  | n+1, .xor a b => (29*shallow n a+31*shallow n b+6)%1000000007
  | n+1, .mux c a b => (37*shallow n c+41*shallow n a+43*shallow n b+7)%1000000007


end CPUProbe
