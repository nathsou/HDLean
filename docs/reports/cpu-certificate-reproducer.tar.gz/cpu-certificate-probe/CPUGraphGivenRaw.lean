import CPUData
import CPUWF
import CPUContext
import ShallowHint
import CheckGiven
open HDLean HDLean.Backend
open Lean Meta Elab Tactic
elab "raw_decide" : tactic => do
  let goal ← getMainGoal
  let type ← instantiateMVars (← goal.getType)
  let pf ← instantiateMVars (← mkDecideProof type)
  let n ← withOptions (Elab.async.set · false) <| mkAuxLemma [] type pf
  goal.assign (mkConst n)
  replaceMainGoal []
set_option maxRecDepth 1000000
set_option maxHeartbeats 16000000
theorem cpuNextSize : CPUStages.candidate.next.size = 4288 := by decide
theorem cpuOutputSize : CPUStages.candidate.outputs.size = 79 := by decide

theorem cpuGraph : CPUStages.candidate.Equivalent (Toy16.Physical.hardware Toy16.sumProgram) := by
  apply Graph.validateGiven_sound CPUStages.candidate
    (Toy16.Physical.hardware Toy16.sumProgram) CPUStages.context cpuWF cpuNextSize cpuOutputSize (CPUProbe.shallow 6)
  raw_decide
