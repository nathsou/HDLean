import IndexByList
open HDLean HDLean.Backend
namespace HDLean.Backend.Local

def checkGiven (g : Graph) (c : Circuit d i r o) (ctx : Context g i r)
    (hw : g.wellFormed = true) (hn : g.next.size = r) (ho : g.outputs.size = o)
    (hint : Expr d i r → Nat := pointerHint) : Option (PLift (g.Equivalent c)) := do
  let table := indexByList ctx
  let job : StateT (Memo g d i r) Option
      (PLift (∀ j : Fin r, j ∈ List.finRange r → meaning g g.next[j.val] = nextMeaning c j) ×
       PLift (∀ j : Fin o, j ∈ List.finRange o → meaning g g.outputs[j.val] = outputMeaning c j)) := do
    let ns ← allChecked (P := fun j : Fin r => meaning g g.next[j.val] = nextMeaning c j) (fun j : Fin r => do liftM (checkRoot (← checkNext c table hint j) g.next[j.val])) (List.finRange r)
    let os ← allChecked (P := fun j : Fin o => meaning g g.outputs[j.val] = outputMeaning c j) (fun j : Fin o => do liftM (checkRoot (← checkOutput c table hint j) g.outputs[j.val])) (List.finRange o)
    return (ns,os)
  let (ns,os) ← job.run' {}
  return ⟨by
    refine ⟨hw,ctx.inputs,ctx.latches,ho,?_⟩
    intro xs s rst
    apply Prod.ext
    · apply Array.ext
      · simp [Graph.eval, hn]
      · intro j h₁ h₂
        have hj : j < r := by simpa using h₂
        have h := ns.down ⟨j,hj⟩ (List.mem_finRange _)
        have h := congrFun (congrFun (congrFun h xs) s) rst
        simpa [Graph.eval, meaning, nextMeaning] using h
    · apply Array.ext
      · simp [Graph.eval, ho]
      · intro j h₁ h₂
        have hj : j < o := by simpa using h₂
        have h := os.down ⟨j,hj⟩ (List.mem_finRange _)
        have h := congrFun (congrFun (congrFun h xs) s) rst
        simpa [Graph.eval, meaning, outputMeaning] using h⟩
end HDLean.Backend.Local
namespace HDLean.Backend

def Graph.validateGiven (g : Graph) (c : Circuit d i r o) (ctx : Local.Context g i r)
    (hw : g.wellFormed = true) (hn : g.next.size = r) (ho : g.outputs.size = o)
    (hint : Expr d i r → Nat := Local.pointerHint) : Bool := (Local.checkGiven g c ctx hw hn ho hint).isSome

theorem Graph.validateGiven_sound (g : Graph) (c : Circuit d i r o) (ctx : Local.Context g i r)
    (hw : g.wellFormed = true) (hn : g.next.size = r) (ho : g.outputs.size = o)
    (hint : Expr d i r → Nat := Local.pointerHint)
    (h : g.validateGiven c ctx hw hn ho hint = true) : g.Equivalent c := by
  unfold Graph.validateGiven at h
  cases hc : Local.checkGiven g c ctx hw hn ho hint with
  | none => simp [hc] at h
  | some proof => exact proof.down
end HDLean.Backend
