# CPU kernel resource experiment

This package preserves a failed resource experiment against HDLean commit
`ef4d7edaf4d47570a2ff4021259f1ed455b818e2`, Lean 4.34.0. It contains no
successful full CPU artifact certificate. The observed result and exact source
hashes are in measurement.json; failed-kernel.log is the actual Lean diagnostic.

The candidate has 40,745 AND gates, 4,288 state bits and the exact logic of the
included 744,329-byte AIGER file. The attempted theorem relates the candidate to
Toy16's physical AST for every state, input and reset. This experiment separately
checks the graph header, uses a linear proof-carrying gate-index builder and a
bounded structural cache hint. CheckGiven and IndexByList include their generic
kernel proofs; arbitrary hints do not establish semantic equality.

Prerequisite: check out the pinned HDLean commit, install its pinned Lean
version, and run `lake build HDLean Designs`. Extract this package into a scratch
directory. Then run (replace paths with your actual checkout/toolchain):

```sh
python3 reproduce.py --project /path/to/HDLean --lean /path/to/lean
```

The runner imports HDLean's bounded process supervisor, writes only to the
specified project's work/ directory by default, deletes stale compiled experiment
outputs, and applies a 64 GiB address-space limit, 12 GiB aggregate resident-memory
limit, 11.5 GiB Lean managed-allocation limit and bounded CPU/wall time per stage.
It uses two Lean threads. This is a development resource probe, not a sandbox for
hostile code or a project approval receipt. Allow several minutes and adequate
physical memory. A resource failure returns nonzero and records the failed stage.
No exact-byte or independent nanoda success follows from a graph-only success.
